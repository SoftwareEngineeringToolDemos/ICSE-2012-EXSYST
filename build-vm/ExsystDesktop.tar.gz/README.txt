Exsyst executable is located in the folder EXSYST on the Desktop. There are sample applications addressbook and calculator located in the same folder. 

You can put the application which you want to test in the EXSYST folder.
Navigate to EXSYST folder in terminal.

Run the below commands (Command is shown as example to run sample applications Calculator and AddressBook, you can replace it with your own application) in the given order.
 
AWT_TOOLKIT=MToolkit

export AWT_TOOLKIT

/usr/lib/jvm/java-6-oracle/jre/bin/java -DTARGET_CLASS_PREFIX=samples -cp exsyst.jar:calculator.jar org.exsyst.UITestSuiteGenerator samples.calculator.CalculatorPanel
		(or)
/usr/lib/jvm/java-6-oracle/jre/bin/java -DTARGET_CLASS_PREFIX=samples -cp exsyst.jar:addressbook.jar org.exsyst.UITestSuiteGenerator samples.addressbook.main.Main -Dglobal_timeout=900

EXSYST works only with Java 6 Runtime.

By default it will run for 10 minutes. You can add the  -Dglobal_timeout=900  option to make it run for 15m.
